<div align="center">
  <h2>It's a lovely day! I hope you're having a great day. I just wanted to wish you a </h2>
  <h1><img width="10%" src="https://media.giphy.com/media/XZUJID3BXY7WH5GkrB/giphy.gif"/>Happy Birthday !<img width="10%" src="https://media.giphy.com/media/XZUJID3BXY7WH5GkrB/giphy.gif"/></h1>
</div>
<div align="center">
  <i>Je suis tellement heureuse de fêter ton anniversaire avec toi ! Tu es un ami très spécial et je veux juste te remercier d'avoir toujours été là pour moi. Vous êtes une source d'inspiration pour moi et j'espère que nous pourrons avoir une belle année devant nous dans l'amitié et l'amour. j'espère que cette année vous apportera tous les succès et le bonheur dans votre carrière en tant que professeur de programmation. Tu es une personne tellement incroyable, le meilleur ami que je puisse demander, je t'aime tellement. <3</i>
</div>

---

> made with 💖 by [@s-shemmee](https://www.github.com/s-shemmee) For [@EladrariSoukaina](https://github.com/soukaina-cloud)
